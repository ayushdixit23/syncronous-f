import React from "react";

function page() {
  return <div className="bg-black">task</div>;
}

export default page;
