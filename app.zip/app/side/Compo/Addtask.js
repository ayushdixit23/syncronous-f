import React from "react";
import Icon from "../../assets/Icon.png";
import Image from "next/image";
function Addtask({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="fixed top-0 left-0 h-screen w-screen flex justify-center items-center bg-opacity-50 bg-gray-800">
      <div className="bg-white p-4 rounded-xl w-[100%] sm:w-[35%] flex-col h-[60%] flex justify-evenly items-center">
        <div className="flex flex-row  h-[8%] justify-between items-center w-[90%] ">
          <div className="text-[16px] text-black flex items-center h-[100%] font-semibold ">
            Add New Task
          </div>
          {/* Add your form or other content here */}
         
        </div>
        <input
          className="p-2 bg-[#FFFBF3] outline-none h-[65%] flex justify-start w-[90%] overflow-auto border-2 rounded-xl border-[#FFC248]"
          placeholder="What is the task?"
        />
        <div className="flex flex-row justify-between items-center w-[90%] space-x-1 h-[10%]">
          <div
            onClick={onClose}
            className="w-[50%] flex justify-center items-center text-black text-[14px] font-semibold h-[100%] bg-white rounded-3xl"
          >
            Cancel
          </div>
          <div className="w-[50%] flex justify-center items-center text-black text-[14px] font-semibold h-[100%] bg-[#FFC248] rounded-3xl">
            Save Task
          </div>
        </div>
      </div>
    </div>
  );
}

export default Addtask;
