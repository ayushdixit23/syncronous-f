import React from "react";
import chit from "../../assets/chit.png";
import Image from "next/image";
import pic from "../../assets/pic.png";
import AddMember from "../../assets/AddMember.png";

function page() {
  return (
    <div className="h-[100%] bg-white font-sans w-[100%] flex flex-col">
      {/* Add member */}
      <div className="h-[10%] w-[100%] flex flex-row">
        <div className="h-[100%] w-[70%] px-2"></div>
        <div className="h-[100%] w-[30%] flex flex-row items-center justify-evenly">
          <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          <div className="w-[20%] h-[70%] flex justify-center   items-center border-l-2 border-slate-500">
            <Image
              src={AddMember}
              className="h-[40px] w-[40px] object-contain"
            />
          </div>
        </div>
      </div>
      <div className="h-[90%]  w-[100%] flex flex-col">
        {/* Receiver */}
        <div className=" flex flex-row">
          <div className="w-[5%] flex justify-center items-start">
            <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          </div>
          <div className="flex flex-col  text-[#344054]">
            {/* Member Name */}
            <div className="flex  items-center flex-row">
              <div className="font-semibold text-[14px]">Vaishali Gupta</div>
            </div>
            {/* Message */}
            <div className="bg-[#FFC977] opacity-95 flex justify-center items-center flex-col max-w-[70%] ">
              <div className="p-2 text-white">
                Hey Olivia, can you please review the latest design when you
                can?sdfrgthjk,kjhredsasdtgyisdefgthcsxder4t5yu
              </div>
              <div className="flex justify-end w-[100%]">
                <div className="text-[12px] text-white flex justify-center items-center px-2 font-medium">
                  Friday 2:20pm
                </div>
                <Image
                  src={chit}
                  className="h-[35px] w-[35px] object-contain "
                />
              </div>
            </div>
          </div>
        </div>

        {/* Sender */}
        <div className=" flex flex-row justify-end ">
          <div className="flex flex-col  text-[#344054]">
            {/* Member Name */}
            <div className="flex flex-col items-end justify-end">
              <div className="font-semibold text-[14px]">Vaishali Gupta</div>
              <div className="bg-[#FFC977] opacity-95 flex justify-center max-w-[70%] items-end flex-col ">
                <div className="p-2 text-white">
                  Hey Olivia, can you please review the latest design when you
                  can?sdfrgthjk,kjhredsasdtgyisdefgthcsxder4t5yu
                </div>
                <div className="flex justify-end w-[100%]">
                  <div className="text-[12px] text-white flex justify-center items-center px-2 font-medium">
                    Friday 2:20pm
                  </div>
                  <Image
                    src={chit}
                    className="h-[35px] w-[35px] object-contain "
                  />
                </div>
              </div>
            </div>
            {/* Message */}
          </div>
          <div className="w-[5%] flex justify-center items-start">
            <Image src={pic} className="h-[40px] w-[40px] object-contain" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default page;
