"use client";
import React, { useEffect, useState } from "react";
import assign from "../../assets/assign.png";
import upload from "../../assets/upload.png";
import figma from "../../assets/figma.png";
import file from "../../assets/file.png";
import pic from "../../assets/pic.png";
import edit from "../../assets/edit.png";
import del from "../../assets/del.png";
import Dropdown from "../../assets/Dropdown.png";
import gallery from "../../assets/gallery.png";
import frame from "../../assets/frame.png";
import Checkbox from "../../assets/Checkbox.png";
import Search from "../../assets/Search.png";
import Image from "next/image";
import { MdDeleteOutline } from "react-icons/md";
import axios from "axios";
function page() {
  const [data, setData] = useState([]);
  const [allorganizations, setAllorganizations] = useState([]);
  const [createteam, setCreateteam] = useState(false);
  const [teamname, setTeamname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  // const [orgname, setOrgname] = useState("");
  const orgname = sessionStorage.getItem("orgname");

  const func = async () => {
    const response = await axios.get("http://localhost:3500/api/get/all-data");
    //console.log(response.data);
    const data = response.data;
    setData(data);

    const organizations = data.map((user) => user.organizations).flat();
    setAllorganizations(organizations);
    console.log(allorganizations);
  };
  // console.log(data.length);
  useEffect(() => {
    func();
  }, []);

  // Create new team
  const create = async () => {
    try {
      const response = await axios.post("http://localhost:3500/api/team", {
        admin: true,
        email,
        teamname,
        password,
      });
      console.log("Team created:", response.data);
      closeModal();
    } catch (error) {
      console.error("Error creating user:", error.message);
      // Handle the error (e.g., display an error message to the user)
    }
  };

  const openModal = () => {
    setCreateteam(true);
  };

  const closeModal = () => {
    setCreateteam(false);
  };
  return (
    <div className="h-[100%] w-full scrollbar-hide flex flex-col items-center ">
      {/* Search members */}
      <div className="h-[10%] bg-white sm:w-[95%] w-full shadow-lg sm:rounded-t-lg flex flex-row items-center justify-between">
        <div className="w-[60%] px-4 h-[100%] text-black font-semibold text-[14px] flex flex-row rounded-xl items-center justify-between">
          Members List
        </div>

        {/* Storage used */}
        <div className="w-[40%] h-[100%]  flex flex-row justify-evenly items-center">
          {/* <div className="flex border-2 rounded-full p-2 border-[#EAEEF4] justify-center items-center">
            <Image src={Search} className="h-[25px] w-[25px] object-contain" />
          </div> */}
          <div
            onClick={openModal}
            className=" rounded-xl flex h-[37px] w-[150px] border-2 text-[14px] text-white bg-[#FFC248] border-[#FFC248] justify-center items-center font-semibold"
          >
            + Create new team
          </div>
          {/* Modal for creating a new team */}
          {createteam && (
            <div className="modal">
              {/* Add your modal content and form for creating a new team here */}
              <div className="fixed top-0 left-0 h-screen w-screen flex justify-center items-center bg-opacity-50 bg-gray-800">
                <div className="bg-white p-4 rounded-xl w-[100%] sm:w-[30%] flex-col h-[50%] flex justify-evenly items-center">
                  <div className="flex flex-row  h-[5%] justify-between items-center w-[90%] ">
                    <div className="text-[16px] text-black flex items-center h-[100%] font-semibold ">
                      Create new team
                    </div>
                    {/* Add your form or other content here */}
                  </div>

                  <input
                    className="p-2 bg-[#FFFBF3] outline-none h-[15%] flex justify-start w-[90%] overflow-auto border-2 rounded-xl border-[#FFC248]"
                    placeholder="Enter Team name"
                    value={teamname}
                    onChange={(e) => setTeamname(e.target.value)}
                  />
                  <input
                    className="p-2 bg-[#FFFBF3] outline-none h-[15%] flex justify-start w-[90%] overflow-auto border-2 rounded-xl border-[#FFC248]"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <input
                    className="p-2 bg-[#FFFBF3] outline-none h-[15%] flex justify-start w-[90%] overflow-auto border-2 rounded-xl border-[#FFC248]"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <div className="flex flex-row justify-between items-center w-[90%] space-x-1 h-[10%]">
                    <div
                      onClick={closeModal}
                      className="w-[50%] flex justify-center items-center text-black text-[14px] font-semibold h-[100%] bg-white rounded-3xl"
                    >
                      Cancel
                    </div>
                    <div
                      onClick={create}
                      className="w-[50%] flex justify-center items-center text-black text-[14px] font-semibold h-[100%] bg-[#FFC248] rounded-3xl"
                    >
                      Create team
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div className=" rounded-xl flex h-[37px] w-[150px] border-2 text-[14px] text-white bg-[#FFC248] border-[#FFC248] justify-center items-center font-semibold">
            + Add Members
          </div>
        </div>
      </div>
      <div className=" text-[#5A5A5A] text-[14px] h-full bg-white sm:rounded-b-lg shadow-lg sm:w-[95%] w-full flex flex-col items-center">
        {/* Header */}
        <div className="flex flex-row bg-[#FFF8EB] font-bold  w-[100%] h-[8%] items-center pn:max-sm:hidden justify-evenly">
          <div className=" w-[25%] px-4">Name</div>
          <div className="w-[15%] flex justify-center items-center">Role</div>
          <div className=" w-[20%] flex justify-center items-center">
            Create Date
          </div>
          <div className=" w-[20%] flex justify-center items-center">
            Position
          </div>
          <div className=" w-[20%] flex justify-center items-center">
            Action
          </div>
        </div>

        {/*Members data */}
        {data.length <= 0 ? (
          <div className="h-[50px] w-[100%]  flex justify-center items-center">
            No members are there
          </div>
        ) : (
          // Members List
          <div className="w-[100%] overflow-auto scrollbar-hide bg-white h-full flex flex-col text-black">
            {allorganizations.map((d, i) =>
              orgname === d?.orgname ? (
                <div
                  key={i}
                  className="flex flex-row my-2 w-[100%] h-[75px] items-center justify-between border-b-[1px] border-[#f1f1f1]"
                >
                  <div className="flex items-center sm:w-[30%] w-[70%] space-x-2 px-2">
                    <Image
                      alt="pic"
                      src={pic}
                      className="h-[40px] w-[40px] object-contain"
                    />
                    <div className="flex flex-col">
                      <div className="text-[14px] font-bold">{d?.username}</div>
                      <div className="text-[12px] ">{d?.email}</div>
                    </div>
                  </div>
                  <div className="w-[15%] pn:max-sm:hidden flex justify-center items-center">
                    <div className="bg-[#EBF6F1] text-[12px] rounded-xl text-[#46BD84] px-4 py-2">
                      {d?.jobrole}
                    </div>
                  </div>
                  <div className="w-[20%] pn:max-sm:hidden text-[12px] flex justify-center items-center">
                    Jan 4, 2022{" "}
                    {/* Modify this part based on the data you want to display */}
                  </div>
                  <div className="w-[20%] pn:max-sm:hidden text-[12px] flex justify-center items-center">
                    HR{" "}
                    {/* Modify this part based on the data you want to display */}
                  </div>
                  <div className="w-[20%] h-full flex flex-row items-center justify-center">
                    <div className="w-[20px] flex justify-start items-center">
                      <MdDeleteOutline className="h-[20px] w-[20px] text-red-400" />
                    </div>
                  </div>
                </div>
              ) : null
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default page;
