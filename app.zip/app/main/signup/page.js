"use client";
import Image from "next/image";
import bgg from "../../assets/mainbg.png";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import axios from "axios";
import { useRouter } from "next/navigation";
// import firebase from "../../../firebase";
// import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";

function page() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState(1);

  //const auth = getAuth(); // Initialize Firebase authentication

  const func = async () => {
    try {
      // Use Firebase authentication to create a new user
      // await createUserWithEmailAndPassword(auth, email, password);
      router.push({
        pathname: "../main/signedup",
        query: {
          email,
          username,
          password,
          phone,
        },
      });
    } catch (error) {
      console.error("Error creating user:", error.message);
      // Handle the error (e.g., display an error message to the user)
    }
  };
  return (
    <div className="w-screen font-sans h-screen bg-[#FFC977] flex justify-center items-center">
      <div className="flex flex-row w-[80%]  h-[80%] items-center justify-between max-lg:justify-center">
        <Image
          src={bgg}
          priority={true}
          alt="pic"
          className="max-lg:hidden object-contain w-[600px] h-[600px]"
        />
        <div className="h-[90%] w-[400px] rounded-2xl bg-white flex flex-col justify-center items-center">
          <div className="flex flex-col h-[80%] justify-evenly">
            <div className="h-[50px]  w-[350px] flex justify-between items-end">
              <div className="text-black text-[26px] font-semibold">
                Sign Up
              </div>
              <div className="flex flex-col">
                <div className="text-[12px] text-[#8D8D8D]">
                  Have An Account ?
                </div>

                <Link
                  href={"/main/signin"}
                  className="text-[#B87514] hover text-[12px]"
                >
                  Sign in
                </Link>
              </div>
            </div>

            <div className="h-[250px] flex flex-col justify-evenly">
              {/* Enter your username or email address */}
              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Enter your email address
                </div>
                <input
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                  }}
                  placeholder="Email address"
                  className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>
              {/* user and contact */}
              <div className="flex flex-row justify-between w-[350px]">
                <div>
                  <div className="text-[14px] font-sans font-semibold text-black">
                    User name
                  </div>
                  <input
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                    }}
                    placeholder=" User name"
                    className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[165px]"
                  />
                </div>
                <div>
                  <div className="text-[14px] font-sans font-semibold text-black">
                    Contact Number
                  </div>
                  <input
                    value={phone}
                    onChange={(e) => {
                      setPhone(e.target.value);
                    }}
                    placeholder="Contact Number"
                    className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[165px]"
                  />
                </div>
              </div>
              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Enter your Password
                </div>
                <input
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                  }}
                  placeholder="Password"
                  type="password"
                  className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>
              {/* <div>
            <div className="text-[14px] font-sans font-semibold text-black">
              Enter Your Job Role
            </div>
            <input
           
              placeholder="Job Role"
              className=" text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
            />
          </div> */}
            </div>
            {/* Sign In */}
            <Link
              href={{
                pathname: "../main/signedup",
                query: { email, username, password, phone },
              }}
              className="bg-[#E48700] text-white text-[12px] flex justify-center items-center rounded-lg h-[40px] w-[350px]"
            >
              Continue
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default page;
