"use client";
import Image from "next/image";
import bgg from "../../assets/mainbg.png";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import axios from "axios";
import { useRouter, useSearchParams } from "next/navigation";
// import firebase from "../../../firebase";

function page() {
  const router = useRouter();
  const search = useSearchParams();
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [dob, setDob] = useState("");
  const [gender, setGender] = useState("");
  const [orgname, setOrgname] = useState("");
  const [jobrole, setJobrole] = useState("");
  const [phone, setPhone] = useState(0);
  const [tasks, setTasks] = useState([]);

  // Access the query parameters
  useEffect(() => {
    // Access the query parameters from the URL

    const email = search.get("email");
    setEmail(email);
    const password = search.get("password");
    setPassword(password);
    const phone = search.get("phone");
    setPhone(phone);
    const username = search.get("username");
    setUsername(username);
    console.log(email);
    console.log(password);
    console.log(phone);
    console.log(username);
  }, []);
  const handleSubmit = async () => {
    try {
      const response = await axios.post("http://localhost:3500/api/send/data", {
        orgname,

        email,
        username,
        jobrole,
        phone,
        password,
        dob,
        gender,
        tasks,
      });
      console.log("User created:", response.data);
      // Optionally, you can redirect to the next page after successful data submission
      sessionStorage.setItem("orgname", orgname);
      router.push("../side/todo");
    } catch (error) {
      console.error("Error creating user:", error.message);
      // Handle the error (e.g., display an error message to the user)
    }
  };
  return (
    <div className="w-screen font-sans h-screen bg-[#FFC977] flex justify-center items-center">
      <div className="flex flex-row w-[80%]  h-[80%] items-center justify-between max-lg:justify-center">
        <Image
          src={bgg}
          priority={true}
          alt="pic"
          className="max-lg:hidden object-contain w-[600px] h-[600px]"
        />
        <div className="h-[90%] w-[400px] rounded-2xl bg-white flex flex-col justify-center items-center">
          <div className="flex flex-col">
            <div className="h-[50px] w-[350px] flex justify-between">
              <div className="text-black text-[26px] font-semibold">
                Sign Up
              </div>
              <div className="flex flex-col">
                <div className="text-[12px] text-[#8D8D8D]">No Account ?</div>

                <Link
                  href={"/main/signup"}
                  className="text-[#B87514] hover text-[12px]"
                >
                  Sign up
                </Link>
              </div>
            </div>

            <div className=" h-[340px] flex flex-col justify-evenly">
              {/* Enter industry */}
              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Create/Join an Organization
                </div>
                <input
                  value={orgname}
                  onChange={(e) => {
                    setOrgname(e.target.value);
                  }}
                  placeholder="Organization name"
                  className=" my-2 text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>
              {/* job */}

              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Enter Your Job Title
                </div>
                <input
                  value={jobrole}
                  onChange={(e) => {
                    setJobrole(e.target.value);
                  }}
                  placeholder="Job Title"
                  className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>

              {/* DOB */}

              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Date of Birth
                </div>
                <input
                  value={dob}
                  onChange={(e) => {
                    setDob(e.target.value);
                  }}
                  placeholder="dd/mmy/yyyy"
                  className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>

              {/* Gender */}

              <div>
                <div className="text-[14px] font-sans font-semibold text-black">
                  Gender
                </div>
                <input
                  value={gender}
                  onChange={(e) => {
                    setGender(e.target.value);
                  }}
                  placeholder="Gender"
                  className="my-2  text-[#808080] text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
                />
              </div>
            </div>
            {/* Continue */}
            <div
              onClick={handleSubmit}
              className="bg-[#E48700] text-white text-[12px] flex justify-center items-center rounded-lg h-[40px] w-[350px]"
            >
              Next
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default page;
