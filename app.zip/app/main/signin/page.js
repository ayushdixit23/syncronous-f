// Import necessary libraries and assets
"use client";
import Image from "next/image";
import bgg from "../../assets/mainbg.png";
import React, { useState } from "react";
import Link from "next/link";
import firebase from "../../../firebase";

// Define the functional component
function LoginPage() {
  const [email, setEmail] = useState(""); // State for email input
  const [password, setPassword] = useState(""); // State for password input

  // Function to handle login
  const handleLogin = async () => {
    try {
      await firebase.auth().signInWithEmailAndPassword(email, password);
      // Redirect or perform actions after successful login
    } catch (error) {
      console.error("Error logging in:", error.message);
      // Handle login error, e.g., show an error message to the user
    }
  };

  return (
    <div className="w-screen font-sans h-screen bg-[#FFC977] flex justify-center items-center">
      <div className="flex flex-row w-[80%] h-[80%] items-center justify-between max-lg:justify-center">
        <Image
          src={bgg}
          priority={true}
          alt="pic"
          className="max-lg:hidden object-contain w-[600px] h-[600px]"
        />
        <div className="h-[90%] w-[400px] rounded-2xl bg-white flex flex-col justify-evenly items-center">
          <div className="h-[50px] w-[350px] flex justify-between">
            <div className="text-black text-[18px] font-semibold">
              Welcome to Sata
            </div>
            <div className="flex flex-col">
              <div className="text-[12px] text-[#8D8D8D]">No Account ?</div>
              <Link
                href={"/main/signup"}
                className="text-[#B87514] hover text-[12px]"
              >
                Sign up
              </Link>
            </div>
          </div>

          {/* Enter your username or email address */}
          <div className="h-[200px] flex flex-col justify-between">
            <div>
              <div className="text-[14px] font-sans font-semibold text-black">
                Enter your email address
              </div>
              <input
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="text-[#808080] my-2 text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
              />
            </div>
            {/* Password */}
            <div>
              <div className="text-[14px] font-sans font-semibold text-black">
                Enter your password
              </div>
              <input
                placeholder="Password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="text-[#808080] my-2 text-[12px] px-2 flex justify-center items-center border-2 outline-none rounded-lg h-[40px] w-[350px]"
              />
            </div>
            <div className="flex h-[40px] items-start w-[350px] justify-end">
              <div className="text-[#AD3113] text-[12px]">Forgot Password</div>
            </div>
          </div>

          {/* Sign In */}
          <button
            onClick={handleLogin}
            className="bg-[#E48700] text-white text-[12px] flex justify-center items-center rounded-lg h-[40px] w-[350px]"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
