export default function MainLayout({ children }) {
  return <div>{children}</div>;
}
