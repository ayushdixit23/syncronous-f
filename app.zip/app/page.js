import React from "react";
import Signin from "./main/signin/page";
function page() {
  return (
    <div>
      <Signin />
    </div>
  );
}

export default page;
